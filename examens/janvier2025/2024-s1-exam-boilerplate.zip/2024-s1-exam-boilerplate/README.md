## IA
- Seul Github Copilot est autorisé.
- N'oubliez pas de soumettre votre fichier chat.json si vous avez utilisé Github Copilot sous VS Code ou chat.txt si vous avez utilisé IntelliJ.