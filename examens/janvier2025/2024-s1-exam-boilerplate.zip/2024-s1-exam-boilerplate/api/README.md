Ce boilerplate d'une application GraphQL a été généré à l'aide du starter d'Apollo Server : https://www.apollographql.com/docs/apollo-server/getting-started

A vous de le mettre à jour comme vous le souhaitez !